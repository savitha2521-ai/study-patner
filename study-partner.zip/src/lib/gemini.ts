import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface StudyContent {
  story: string;
  podcastScript: string; // Explicit script for TTS
  mindMap: {
    nodes: { id: string; label: string; type: 'root' | 'main' | 'sub' }[];
    links: { source: string; target: string }[];
  };
  flowchart: {
    steps: { id: string; text: string; description: string }[];
  };
  infographic: {
    keyPoints: { title: string; value: string; icon: string }[];
    summary: string;
  };
  quiz: {
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }[];
  studyPlan: {
    subject: string;
    dailySchedule: { day: string; topics: string[]; goal: string }[];
    topics: { name: string; duration: string; priority: 'high' | 'medium' | 'low'; resources: string }[];
    strategy: string;
    examTips: string[];
  }[];
}

export async function generateSpeech(text: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Read this study material podcast script in a friendly, engaging, and educational tone: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' }, // Friendly female voice
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("No audio data generated");
    return base64Audio;
  } catch (error) {
    console.error("TTS Generation failed:", error);
    throw error;
  }
}

export async function analyzeStudyMaterial(
  fileData: string, 
  mimeType: string, 
  language: string,
  examState: string,
  dateRange: string
): Promise<StudyContent> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze the provided study material and generate a comprehensive learning package in ${language}.
    
    The package must include:
    1. A storytelling-style "podcast" script explaining the core concepts.
    2. A separate, concise "podcastScript" specifically optimized for text-to-speech (no stage directions, just the spoken text).
    3. A mind map structure (nodes and links).
    4. A logical flowchart of processes or concepts.
    5. An infographic summary with key data points.
    6. A 5-question quiz with explanations.
    7. A highly detailed, personalized study strategy for an exam in ${examState} within the date range ${dateRange}. Include a daily schedule and specific exam tips.
    
    Format the output as a JSON object matching the following schema:
    {
      "story": "string",
      "podcastScript": "string",
      "mindMap": { "nodes": [{ "id": "string", "label": "string", "type": "root|main|sub" }], "links": [{ "source": "string", "target": "string" }] },
      "flowchart": { "steps": [{ "id": "string", "text": "string", "description": "string" }] },
      "infographic": { "keyPoints": [{ "title": "string", "value": "string", "icon": "string" }], "summary": "string" },
      "quiz": [{ "question": "string", "options": ["string"], "correctAnswer": 0, "explanation": "string" }],
      "studyPlan": [{ 
        "subject": "string", 
        "dailySchedule": [{ "day": "string", "topics": ["string"], "goal": "string" }],
        "topics": [{ "name": "string", "duration": "string", "priority": "high|medium|low", "resources": "string" }], 
        "strategy": "string",
        "examTips": ["string"]
      }]
    }
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { text: prompt },
          { inlineData: { data: fileData, mimeType } }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
    }
  });

  const text = response.text || "{}";
  try {
    // Attempt direct parse first
    return JSON.parse(text);
  } catch (e) {
    console.warn("Direct JSON parse failed, attempting to extract JSON block:", e);
    // Fallback: Extract the first JSON-like block
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[0]);
      } catch (innerError) {
        console.error("Failed to parse extracted JSON block:", innerError);
        throw new Error("Invalid study material analysis format received from AI.");
      }
    }
    throw new Error("No valid analysis data found in AI response.");
  }
}
