/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, Suspense, lazy, useMemo, useCallback } from 'react';
import Background3D from './components/Background3D';
import { analyzeStudyMaterial, StudyContent } from './lib/gemini';
import { auth, onAuthStateChanged, db, handleFirestoreError, OperationType } from './lib/firebase';
import { Button } from './components/ui/button';
import { doc, setDoc, serverTimestamp, collection } from 'firebase/firestore';
import { AnimatePresence, motion } from 'motion/react';
import { XCircle } from 'lucide-react';

const Auth = lazy(() => import('./components/Auth'));
const LandingPage = lazy(() => import('./components/LandingPage'));
const Dashboard = lazy(() => import('./components/Dashboard'));

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, error: null };

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    return { hasError: true, error };
  }

  render() {
    const { hasError, error } = this.state;
    if (hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 text-center bg-brand-paper">
          <div className="max-w-md space-y-8 bento-card border-brand-ink/5 shadow-2xl bg-white">
            <div className="h-20 w-20 bg-red-100 rounded-3xl flex items-center justify-center mx-auto">
              <XCircle className="w-10 h-10 text-red-600" />
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-display font-black tracking-tight text-brand-ink">Something went wrong</h2>
              <p className="text-brand-ink/60 font-medium">We encountered an <span className="font-serif italic text-brand-ink">unexpected</span> error while processing your request.</p>
            </div>
            <div className="p-6 bg-brand-ink/5 rounded-2xl text-left overflow-hidden">
              <p className="text-[10px] font-black uppercase tracking-widest opacity-40 mb-2">Error Details</p>
              <pre className="text-xs font-mono opacity-70 whitespace-pre-wrap break-all max-h-40 overflow-auto">
                {error?.message || String(error)}
              </pre>
            </div>
            <Button 
              onClick={() => window.location.reload()} 
              className="w-full h-14 bg-brand-ink text-brand-paper rounded-2xl font-display font-black text-lg shadow-xl active:scale-95"
            >
              Reload Application
            </Button>
          </div>
        </div>
      );
    }
    return (this as any).props.children;
  }
}

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [studyContent, setStudyContent] = useState<StudyContent | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
      
      if (currentUser) {
        // Sync user to Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        setDoc(userRef, {
          uid: currentUser.uid,
          email: currentUser.email,
          displayName: currentUser.displayName,
          createdAt: serverTimestamp()
        }, { merge: true }).catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}`));
      }
    });
    return () => unsubscribe();
  }, []);

  const handleAnalyze = useCallback(async (fileData: string, mimeType: string, config: any) => {
    if (!user) return;
    setIsAnalyzing(true);
    try {
      const content = await analyzeStudyMaterial(
        fileData, 
        mimeType, 
        config.language, 
        config.examState, 
        config.dateRange
      );
      
      // Save session to Firestore
      const sessionRef = doc(collection(db, 'users', user.uid, 'sessions'));
      await setDoc(sessionRef, {
        userId: user.uid,
        content,
        language: config.language,
        examState: config.examState,
        dateRange: config.dateRange,
        createdAt: serverTimestamp()
      });

      setStudyContent(content);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  }, [user]);

  const mainContent = useMemo(() => (
    <AnimatePresence mode="wait">
      {!user ? (
        <motion.div
          key="auth"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <Auth onLogin={setUser} />
        </motion.div>
      ) : !studyContent ? (
        <motion.div
          key="landing"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <LandingPage onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
        </motion.div>
      ) : (
        <motion.div
          key="dashboard"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <Dashboard 
            content={studyContent} 
            onReset={() => setStudyContent(null)} 
          />
        </motion.div>
      )}
    </AnimatePresence>
  ), [user, studyContent, isAnalyzing, handleAnalyze]);

  if (!isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-paper">
        <motion.div 
          animate={{ 
            opacity: [0.3, 1, 0.3],
            scale: [0.98, 1, 0.98]
          }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="text-4xl font-display font-black tracking-tighter text-brand-ink"
        >
          Study <span className="font-serif italic font-normal text-brand-electric">Partner</span>
        </motion.div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="relative min-h-screen font-sans bg-brand-paper selection:bg-brand-ink selection:text-brand-paper">
        <Background3D />
        
        <Suspense fallback={
          <div className="flex items-center justify-center h-screen">
            <div className="w-12 h-12 border-4 border-brand-ink border-t-transparent rounded-full animate-spin" />
          </div>
        }>
          {mainContent}
        </Suspense>

        {/* Footer */}
        <footer className="fixed bottom-6 left-0 right-0 text-center text-[10px] uppercase tracking-[0.3em] font-black opacity-20 pointer-events-none">
          Study Partner &copy; 2026 • <span className="font-serif italic lowercase tracking-normal opacity-100">powered by</span> Gemini AI
        </footer>
      </div>
    </ErrorBoundary>
  );
}
