import React, { useState, useMemo, memo, useCallback, useEffect, useRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Play, 
  Pause, 
  Network, 
  GitBranch, 
  BarChart3, 
  HelpCircle, 
  Calendar, 
  MessageSquare,
  ChevronRight,
  CheckCircle2,
  XCircle,
  RefreshCcw,
  Volume2,
  Star,
  User,
  Clock,
  Target,
  Lightbulb
} from 'lucide-react';
import { StudyContent, generateSpeech } from '@/lib/gemini';
import { motion, AnimatePresence } from 'motion/react';
import { db, auth, handleFirestoreError, OperationType } from '@/lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';

const pcmToWav = (pcmBase64: string, sampleRate: number = 24000) => {
  const binaryString = atob(pcmBase64);
  const len = binaryString.length;
  const buffer = new ArrayBuffer(44 + len);
  const view = new DataView(buffer);

  const writeString = (offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + len, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, len, true);

  for (let i = 0; i < len; i++) {
    view.setUint8(44 + i, binaryString.charCodeAt(i));
  }

  return new Blob([buffer], { type: 'audio/wav' });
};

const PodcastTab = memo(({ content, isPlaying, onTogglePlay, audioLoading }: { 
  content: StudyContent, 
  isPlaying: boolean, 
  onTogglePlay: () => void,
  audioLoading: boolean
}) => (
  <div className="bento-card bg-brand-paper border-brand-ink/5 shadow-2xl overflow-hidden">
    <div className="flex flex-col md:flex-row items-center gap-12 p-12">
      <div className="relative shrink-0">
        <div className={`absolute inset-0 bg-brand-electric/20 rounded-full blur-2xl transition-all duration-1000 ${isPlaying ? 'scale-150 opacity-100' : 'scale-100 opacity-0'}`} />
        <button 
          disabled={audioLoading}
          className="relative h-48 w-48 rounded-[3rem] bg-brand-ink flex items-center justify-center text-brand-paper cursor-pointer hover:scale-105 transition-all shadow-2xl disabled:opacity-50 group active:scale-95" 
          onClick={onTogglePlay}
        >
          {audioLoading ? (
            <RefreshCcw className="w-16 h-16 animate-spin" />
          ) : isPlaying ? (
            <Pause className="w-16 h-16" />
          ) : (
            <Play className="w-16 h-16 ml-3 group-hover:scale-110 transition-transform" />
          )}
        </button>
      </div>
      <div className="space-y-8 flex-1">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="px-3 py-1 bg-brand-electric text-white text-[10px] font-black uppercase tracking-widest rounded-full">
              Audio Experience
            </div>
            <div className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-brand-ink/40">
              <Volume2 className="w-3 h-3" /> Immersive Learning
            </div>
          </div>
          <h3 className="text-5xl font-display font-black tracking-tighter leading-none text-brand-ink">
            The <span className="font-serif italic font-normal text-brand-electric">Podcast</span>
          </h3>
          <p className="text-2xl leading-tight font-serif italic text-brand-ink/80">
            "{content.story}"
          </p>
        </div>
        
        <div className="p-10 bg-brand-ink/5 rounded-[2.5rem] border border-brand-ink/10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:scale-110 transition-transform">
            <MessageSquare className="w-12 h-12" />
          </div>
          <p className="text-[10px] font-black mb-4 uppercase tracking-[0.2em] text-brand-ink/40">Podcast Script</p>
          <p className="text-lg leading-relaxed font-medium text-brand-ink/90">{content.podcastScript}</p>
        </div>
      </div>
    </div>
  </div>
));

const VisualsTab = memo(({ content }: { content: StudyContent }) => (
  <div className="grid md:grid-cols-12 gap-8">
    <div className="md:col-span-7 bento-card border-brand-ink/5 shadow-2xl bg-white/50 backdrop-blur-xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-3xl font-display font-black tracking-tight">Mind Map</h3>
          <p className="text-sm opacity-60 font-medium">Visualizing core concepts.</p>
        </div>
        <Network className="w-8 h-8 text-brand-electric opacity-20" />
      </div>
      <div className="h-[500px] relative rounded-[2rem] border border-brand-ink/5 bg-brand-ink/[0.02] overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center p-8">
          <div className="w-full h-full flex flex-col items-center justify-center gap-6 overflow-auto p-8">
            {content.mindMap.nodes.map((node, i) => (
              <motion.div
                key={node.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`px-8 py-4 rounded-2xl border shadow-xl transition-all hover:scale-105 ${
                  node.type === 'root' 
                    ? 'bg-brand-ink text-brand-paper font-display font-black text-xl border-brand-ink' 
                    : 'bg-white text-brand-ink font-bold border-brand-ink/10'
                }`}
              >
                {node.label}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>

    <div className="md:col-span-5 bento-card border-brand-ink/5 shadow-2xl bg-brand-ink text-brand-paper">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-3xl font-display font-black tracking-tight">Flowchart</h3>
          <p className="text-sm opacity-40 font-medium">Logical progression.</p>
        </div>
        <GitBranch className="w-8 h-8 text-brand-mint opacity-40" />
      </div>
      <ScrollArea className="h-[450px] pr-6">
        <div className="space-y-10">
          {content.flowchart.steps.map((step, i) => (
            <div key={step.id} className="relative flex gap-6">
              {i < content.flowchart.steps.length - 1 && (
                <div className="absolute left-[15px] top-10 bottom-[-30px] w-[2px] bg-white/10" />
              )}
              <div className="h-8 w-8 rounded-xl bg-brand-mint text-brand-ink flex items-center justify-center text-xs font-black shrink-0 z-10 shadow-lg">
                {i + 1}
              </div>
              <div className="space-y-2">
                <p className="text-xl font-display font-bold leading-none">{step.text}</p>
                <p className="text-sm opacity-50 font-medium leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>

    <div className="md:col-span-12 bento-card border-brand-ink/5 shadow-2xl bg-brand-mint/10">
      <div className="flex items-center justify-between mb-12">
        <div>
          <h3 className="text-4xl font-display font-black tracking-tight">Infographic Summary</h3>
          <p className="text-lg opacity-60 font-medium">Key takeaways at a glance.</p>
        </div>
        <BarChart3 className="w-10 h-10 text-brand-ink opacity-20" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
        {content.infographic.keyPoints.map((point, i) => (
          <div key={i} className="p-8 bg-white/80 rounded-[2rem] border border-brand-ink/5 space-y-3 shadow-xl hover:bg-white transition-all hover:-translate-y-1">
            <p className="text-[10px] uppercase tracking-[0.2em] opacity-40 font-black">{point.title}</p>
            <p className="text-3xl font-display font-black text-brand-ink">{point.value}</p>
          </div>
        ))}
      </div>
      <div className="p-10 border border-brand-ink/5 rounded-[2.5rem] bg-white/40 backdrop-blur-sm shadow-inner">
        <p className="text-2xl leading-relaxed font-serif italic text-brand-ink/80 text-center">
          "{content.infographic.summary}"
        </p>
      </div>
    </div>
  </div>
));

const QuizTab = memo(({ content, quizAnswers, showResults, onAnswer, onSubmit }: { 
  content: StudyContent, 
  quizAnswers: Record<number, number>, 
  showResults: boolean, 
  onAnswer: (q: number, o: number) => void,
  onSubmit: () => void,
  score: number 
}) => (
  <div className="bento-card border-brand-ink/5 shadow-2xl bg-white/50 backdrop-blur-xl">
    <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-8">
      <div className="space-y-2">
        <h3 className="text-4xl font-display font-black tracking-tight">Knowledge Check</h3>
        <p className="text-lg opacity-60 font-medium">Test your understanding of the <span className="font-serif italic text-brand-ink">concepts</span>.</p>
      </div>
      {showResults && (
        <div className="p-8 bg-brand-ink text-brand-paper rounded-[2rem] text-center min-w-[200px] shadow-2xl">
          <p className="text-6xl font-display font-black tracking-tighter">
            {Object.entries(quizAnswers).reduce((acc, [i, ans]) => acc + (ans === content.quiz[Number(i)].correctAnswer ? 1 : 0), 0)}
            <span className="text-2xl opacity-40 ml-1">/ {content.quiz.length}</span>
          </p>
          <p className="text-[10px] uppercase tracking-widest font-black opacity-40 mt-2">Your Score</p>
        </div>
      )}
    </div>
    
    <div className="space-y-12">
      {content.quiz.map((q, qIndex) => (
        <div key={qIndex} className="space-y-8 p-10 rounded-[2.5rem] bg-brand-ink/[0.02] border border-brand-ink/5">
          <div className="flex gap-6">
            <div className="h-10 w-10 rounded-2xl bg-brand-ink text-brand-paper flex items-center justify-center text-sm font-black shrink-0 shadow-lg">
              {qIndex + 1}
            </div>
            <p className="text-2xl font-display font-bold leading-tight">{q.question}</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            {q.options.map((option, oIndex) => {
              const isSelected = quizAnswers[qIndex] === oIndex;
              const isCorrect = oIndex === q.correctAnswer;
              let variant = "outline";
              if (showResults) {
                if (isCorrect) variant = "correct";
                else if (isSelected) variant = "incorrect";
              } else if (isSelected) {
                variant = "selected";
              }

              return (
                <button
                  key={oIndex}
                  disabled={showResults}
                  onClick={() => onAnswer(qIndex, oIndex)}
                  className={`w-full text-left p-6 rounded-2xl border transition-all flex items-center justify-between group h-full ${
                    variant === "correct" ? "bg-green-500 border-green-600 text-white shadow-lg" :
                    variant === "incorrect" ? "bg-red-500 border-red-600 text-white shadow-lg" :
                    variant === "selected" ? "bg-brand-ink border-brand-ink text-brand-paper shadow-xl scale-[1.02]" :
                    "bg-white border-brand-ink/10 hover:border-brand-ink/30 hover:bg-white/80"
                  }`}
                >
                  <span className="text-lg font-medium">{option}</span>
                  {showResults && isCorrect && <CheckCircle2 className="w-6 h-6" />}
                  {showResults && isSelected && !isCorrect && <XCircle className="w-6 h-6" />}
                </button>
              );
            })}
          </div>
          
          {showResults && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 bg-brand-electric/10 text-brand-ink rounded-[2rem] border border-brand-electric/20"
            >
              <div className="flex items-center gap-3 mb-3">
                <Lightbulb className="w-6 h-6 text-brand-electric" />
                <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Explanation</p>
              </div>
              <p className="text-lg font-medium leading-relaxed opacity-80 italic">"{q.explanation}"</p>
            </motion.div>
          )}
        </div>
      ))}
      
      {!showResults && (
        <Button 
          className="w-full h-20 bg-brand-ink text-brand-paper text-2xl font-display font-black rounded-[2rem] shadow-2xl transition-all active:scale-95 hover:bg-brand-ink/90 disabled:opacity-50"
          disabled={Object.keys(quizAnswers).length < content.quiz.length}
          onClick={onSubmit}
        >
          Submit Knowledge Check
        </Button>
      )}
    </div>
  </div>
));

interface DashboardProps {
  content: StudyContent;
  onReset: () => void;
}

export default function Dashboard({ content, onReset }: DashboardProps) {
  const [activeTab, setActiveTab] = useState('podcast');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioLoading, setAudioLoading] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [reviews, setReviews] = useState<any[]>([]);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'reviews'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setReviews(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reviews');
    });
    return () => unsubscribe();
  }, []);

  const togglePlay = async () => {
    if (isPlaying) {
      audioRef.current?.pause();
      setIsPlaying(false);
      return;
    }

    if (audioRef.current) {
      audioRef.current.play();
      setIsPlaying(true);
      return;
    }

    try {
      setAudioLoading(true);
      const base64Audio = await generateSpeech(content.podcastScript);
      const audioBlob = pcmToWav(base64Audio);
      const audioUrl = URL.createObjectURL(audioBlob);
      
      const audio = new Audio(audioUrl);
      audio.onended = () => setIsPlaying(false);
      audio.onerror = (e) => {
        console.error("Audio element error:", e);
        setIsPlaying(false);
      };
      audioRef.current = audio;
      audio.play();
      setIsPlaying(true);
    } catch (error) {
      console.error("Audio playback failed:", error);
    } finally {
      setAudioLoading(false);
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !newReview.comment.trim()) return;

    setIsSubmittingReview(true);
    try {
      await addDoc(collection(db, 'reviews'), {
        userId: auth.currentUser.uid,
        userName: auth.currentUser.displayName || 'Anonymous',
        userPhoto: auth.currentUser.photoURL || '',
        rating: newReview.rating,
        comment: newReview.comment,
        createdAt: serverTimestamp()
      });
      setNewReview({ rating: 5, comment: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'reviews');
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const score = useMemo(() => {
    return content.quiz.reduce((acc, q, i) => {
      return acc + (quizAnswers[i] === q.correctAnswer ? 1 : 0);
    }, 0);
  }, [content.quiz, quizAnswers]);

  const handleTopicClick = (type: 'podcast' | 'visuals' | 'quiz') => {
    setActiveTab(type);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen p-6 md:p-12 text-brand-ink selection:bg-brand-ink selection:text-brand-paper">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="flex flex-col md:flex-row justify-between items-end gap-8 border-b border-brand-ink/10 pb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="px-3 py-1 bg-brand-mint rounded-full text-[10px] font-black uppercase tracking-widest border border-brand-ink/5">
                Active Session
              </div>
              <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest opacity-40">
                <Clock className="w-3 h-3" /> {new Date().toLocaleDateString()}
              </div>
            </div>
            <h2 className="text-6xl md:text-7xl font-display font-black tracking-tighter leading-none">
              Study <span className="font-serif italic font-normal text-brand-electric">Session</span>
            </h2>
            <p className="text-xl opacity-60 max-w-xl font-medium">
              Your personalized learning path, <span className="font-serif italic">meticulously</span> crafted by AI.
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={onReset} 
            className="h-14 px-8 rounded-2xl border-brand-ink/10 hover:bg-brand-ink hover:text-brand-paper transition-all font-display font-bold text-lg shadow-xl active:scale-95"
          >
            <RefreshCcw className="w-5 h-5 mr-3" />
            New Material
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="flex flex-wrap h-auto gap-2 bg-transparent p-0 mb-12">
            {[
              { value: 'podcast', label: 'Podcast', icon: Volume2 },
              { value: 'visuals', label: 'Visuals', icon: Network },
              { value: 'quiz', label: 'Quiz', icon: HelpCircle },
              { value: 'plan', label: 'Study Plan', icon: Calendar },
              { value: 'feedback', label: 'Reviews', icon: MessageSquare },
            ].map((tab) => (
              <TabsTrigger 
                key={tab.value}
                value={tab.value} 
                className="data-[state=active]:bg-brand-ink data-[state=active]:text-brand-paper data-[state=active]:shadow-2xl h-12 px-6 rounded-2xl border border-brand-ink/5 bg-white/50 backdrop-blur-sm font-display font-bold transition-all hover:bg-white/80 flex items-center gap-2"
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="mt-8">
            <TabsContent value="podcast" className="focus-visible:outline-none">
              <PodcastTab 
                content={content} 
                isPlaying={isPlaying} 
                onTogglePlay={togglePlay} 
                audioLoading={audioLoading}
              />
            </TabsContent>

            <TabsContent value="visuals" className="focus-visible:outline-none">
              <VisualsTab content={content} />
            </TabsContent>

            <TabsContent value="quiz" className="focus-visible:outline-none">
              <QuizTab 
                content={content} 
                quizAnswers={quizAnswers} 
                showResults={showResults} 
                onAnswer={(q, o) => setQuizAnswers(prev => ({ ...prev, [q]: o }))}
                onSubmit={() => setShowResults(true)}
                score={score}
              />
            </TabsContent>

            <TabsContent value="plan" className="focus-visible:outline-none">
              <div className="grid md:grid-cols-12 gap-8">
                <div className="md:col-span-8 bento-card !p-0 overflow-hidden border-brand-ink/5 shadow-2xl">
                  <div className="p-10 border-b border-brand-ink/5 bg-brand-ink text-brand-paper">
                    <div className="flex items-center gap-3 mb-4">
                      <Calendar className="w-6 h-6 text-brand-mint" />
                      <h3 className="text-3xl font-display font-black tracking-tight">Detailed Roadmap</h3>
                    </div>
                    <p className="opacity-60 font-medium">A step-by-step strategy to <span className="font-serif italic">master</span> your material.</p>
                  </div>
                  <div className="p-10">
                    <ScrollArea className="h-[600px] pr-6">
                      <div className="space-y-16">
                        {content.studyPlan.map((plan, i) => (
                          <div key={i} className="space-y-12">
                            <div className="flex items-center justify-between border-b border-brand-ink/10 pb-6">
                              <h4 className="text-4xl font-display font-black tracking-tighter">{plan.subject}</h4>
                              <div className="px-4 py-1.5 bg-brand-mint text-brand-ink text-[10px] rounded-full font-black uppercase tracking-widest border border-brand-ink/5">
                                Primary Goal
                              </div>
                            </div>

                            <div className="space-y-8">
                              <h5 className="text-xl font-display font-bold flex items-center gap-3">
                                <Clock className="w-6 h-6 text-brand-electric" /> Daily Schedule
                              </h5>
                              <div className="grid gap-6">
                                {plan.dailySchedule.map((day, j) => (
                                  <div key={j} className="p-8 bg-white/50 rounded-3xl border border-brand-ink/5 space-y-4 hover:bg-white transition-colors">
                                    <div className="flex justify-between items-center">
                                      <p className="font-display font-bold text-2xl">{day.day}</p>
                                      <span className="text-[10px] font-black uppercase tracking-widest opacity-40">{day.goal}</span>
                                    </div>
                                    <div className="flex flex-wrap gap-2">
                                      {day.topics.map((topic, k) => (
                                        <button 
                                          key={k} 
                                          onClick={() => handleTopicClick('podcast')}
                                          className="px-3 py-1.5 bg-brand-ink/5 rounded-xl text-sm font-medium hover:bg-brand-electric hover:text-white transition-all active:scale-95 cursor-pointer"
                                        >
                                          {topic}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-8">
                              <h5 className="text-xl font-display font-bold flex items-center gap-3">
                                <Target className="w-6 h-6 text-brand-electric" /> Topic Breakdown
                              </h5>
                              <div className="grid gap-6">
                                {plan.topics.map((topic, j) => (
                                  <button 
                                    key={j} 
                                    onClick={() => handleTopicClick('visuals')}
                                    className="w-full text-left p-8 bg-brand-ink/5 rounded-3xl space-y-4 hover:bg-brand-ink/10 transition-all active:scale-[0.99] group cursor-pointer border border-transparent hover:border-brand-ink/10"
                                  >
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-4">
                                        <div className={`h-4 w-4 rounded-full shadow-lg ${
                                          topic.priority === 'high' ? 'bg-red-500' : 
                                          topic.priority === 'medium' ? 'bg-orange-500' : 'bg-green-500'
                                        }`} />
                                        <p className="font-display font-bold text-xl">{topic.name}</p>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <p className="text-sm font-mono font-bold opacity-40">{topic.duration}</p>
                                        <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-40 transition-opacity" />
                                      </div>
                                    </div>
                                    <p className="text-sm opacity-60 font-serif italic">Resources: {topic.resources}</p>
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="p-10 bg-brand-ink text-brand-paper rounded-[2.5rem] space-y-6 shadow-2xl relative overflow-hidden">
                              <div className="absolute top-0 right-0 p-8 opacity-5">
                                <Lightbulb className="w-32 h-32" />
                              </div>
                              <h5 className="text-2xl font-display font-black flex items-center gap-3 relative z-10">
                                <Lightbulb className="w-8 h-8 text-yellow-400" /> Exam Strategy
                              </h5>
                              <p className="text-lg leading-relaxed opacity-80 font-medium relative z-10">{plan.strategy}</p>
                              <div className="grid md:grid-cols-2 gap-6 pt-6 border-t border-white/10 relative z-10">
                                {plan.examTips.map((tip, j) => (
                                  <div key={j} className="flex gap-4 items-start">
                                    <CheckCircle2 className="w-6 h-6 text-brand-mint shrink-0" />
                                    <p className="text-sm opacity-90 leading-tight">{tip}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>

                <div className="md:col-span-4 space-y-8">
                  <div className="bento-card bg-brand-ink text-brand-paper border-none shadow-2xl overflow-hidden relative">
                    <div className="absolute top-0 right-0 w-48 h-48 bg-brand-electric/20 rounded-full -mr-24 -mt-24 blur-[100px]" />
                    <div className="relative z-10 space-y-10">
                      <div>
                        <h3 className="text-2xl font-display font-black tracking-tight">Exam Readiness</h3>
                        <p className="text-sm text-white/40 font-medium mt-1">AI-powered assessment.</p>
                      </div>
                      <div className="text-center space-y-2">
                        <p className="text-8xl font-display font-black tracking-tighter">{Math.round((score / content.quiz.length) * 100)}%</p>
                        <p className="text-[10px] uppercase tracking-[0.2em] font-black opacity-40">Current Mastery</p>
                      </div>
                      <div className="space-y-6">
                        <div className="space-y-3">
                          <div className="flex justify-between text-[10px] font-black uppercase tracking-widest opacity-60">
                            <span>Concept Mastery</span>
                            <span>{Math.round((score / content.quiz.length) * 90)}%</span>
                          </div>
                          <Progress value={(score / content.quiz.length) * 90} className="h-1.5 bg-white/10" />
                        </div>
                        <div className="space-y-3">
                          <div className="flex justify-between text-[10px] font-black uppercase tracking-widest opacity-60">
                            <span>Retention Potential</span>
                            <span>75%</span>
                          </div>
                          <Progress value={75} className="h-1.5 bg-white/10" />
                        </div>
                      </div>
                      <Button className="w-full bg-brand-paper text-brand-ink hover:bg-brand-mint font-display font-black h-14 rounded-2xl shadow-xl transition-all active:scale-95">
                        Optimize Strategy
                      </Button>
                    </div>
                  </div>

                  <div className="bento-card border-brand-ink/5 bg-brand-mint/20">
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 mb-8">Session Stats</h3>
                    <div className="space-y-6">
                      <div className="flex justify-between items-center border-b border-brand-ink/5 pb-4">
                        <span className="text-sm font-bold opacity-60">Topics Covered</span>
                        <span className="font-display font-black text-2xl">{content.studyPlan[0]?.topics.length || 0}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-brand-ink/5 pb-4">
                        <span className="text-sm font-bold opacity-60">Quiz Questions</span>
                        <span className="font-display font-black text-2xl">{content.quiz.length}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-bold opacity-60">Est. Study Time</span>
                        <span className="font-display font-black text-2xl">4.5h</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="feedback" className="focus-visible:outline-none">
              <div className="grid md:grid-cols-12 gap-8">
                <div className="md:col-span-8 bento-card !p-0 overflow-hidden border-brand-ink/5 shadow-2xl">
                  <div className="p-10 border-b border-brand-ink/5">
                    <div className="flex items-center gap-3 mb-4">
                      <MessageSquare className="w-6 h-6 text-brand-electric" />
                      <h3 className="text-3xl font-display font-black tracking-tight">Community Feedback</h3>
                    </div>
                    <p className="opacity-60 font-medium">See what other <span className="font-serif italic text-brand-ink">scholars</span> are saying.</p>
                  </div>
                  <div className="p-10">
                    <ScrollArea className="h-[500px] pr-6">
                      <div className="space-y-8">
                        {reviews.map((review) => (
                          <div key={review.id} className="p-8 bg-white/50 rounded-[2rem] border border-brand-ink/5 space-y-6 hover:bg-white transition-all group">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-4">
                                {review.userPhoto ? (
                                  <img src={review.userPhoto} alt={review.userName} className="h-12 w-12 rounded-2xl shadow-lg group-hover:rotate-3 transition-transform" referrerPolicy="no-referrer" />
                                ) : (
                                  <div className="h-12 w-12 rounded-2xl bg-brand-ink flex items-center justify-center text-brand-paper shadow-lg">
                                    <User className="w-6 h-6" />
                                  </div>
                                )}
                                <div>
                                  <p className="font-display font-bold text-lg leading-none">{review.userName}</p>
                                  <div className="flex gap-1 mt-1.5">
                                    {[...Array(5)].map((_, i) => (
                                      <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-brand-ink/10'}`} />
                                    ))}
                                  </div>
                                </div>
                              </div>
                              <p className="text-[10px] font-black uppercase tracking-widest opacity-30">
                                {review.createdAt?.toDate?.()?.toLocaleDateString() || 'Just now'}
                              </p>
                            </div>
                            <p className="text-lg leading-relaxed opacity-70 font-medium italic">"{review.comment}"</p>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>

                <div className="md:col-span-4 bento-card border-brand-ink/5 bg-brand-paper shadow-2xl">
                  <h3 className="text-2xl font-display font-black tracking-tight mb-2">Leave a Review</h3>
                  <p className="text-sm opacity-60 font-medium mb-8">Share your <span className="font-serif italic">wisdom</span> with the community.</p>
                  <form onSubmit={handleReviewSubmit} className="space-y-8">
                    <div className="space-y-3">
                      <label className="text-[10px] font-black uppercase tracking-widest opacity-40 ml-1">Rating</label>
                      <div className="flex gap-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setNewReview(prev => ({ ...prev, rating: star }))}
                            className={`h-12 w-12 rounded-2xl border transition-all flex items-center justify-center ${
                              newReview.rating >= star ? 'bg-yellow-400 border-yellow-500 text-white shadow-lg scale-110' : 'bg-white border-brand-ink/10 hover:border-brand-ink/20'
                            }`}
                          >
                            <Star className={`w-5 h-5 ${newReview.rating >= star ? 'fill-current' : ''}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black uppercase tracking-widest opacity-40 ml-1">Your Feedback</label>
                      <Textarea 
                        placeholder="How did Study Partner help you today?"
                        className="min-h-[160px] bg-white/50 border-brand-ink/5 rounded-[2rem] p-6 focus:ring-brand-electric/20 resize-none font-medium"
                        value={newReview.comment}
                        onChange={(e) => setNewReview(prev => ({ ...prev, comment: e.target.value }))}
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full bg-brand-ink text-brand-paper h-16 rounded-[2rem] font-display font-black text-lg shadow-2xl transition-all active:scale-95 disabled:opacity-50"
                      disabled={isSubmittingReview || !newReview.comment.trim()}
                    >
                      {isSubmittingReview ? <RefreshCcw className="w-6 h-6 animate-spin" /> : 'Post Review'}
                    </Button>
                  </form>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}
