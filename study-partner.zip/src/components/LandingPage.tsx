import React, { useState, useCallback, memo } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, Image as ImageIcon, Loader2, Globe, Sparkles, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'motion/react';

interface LandingPageProps {
  onAnalyze: (data: string, mimeType: string, config: any) => void;
  isAnalyzing: boolean;
}

const FeatureItem = memo(({ title, desc, index }: { title: string, desc: string, index: number }) => (
  <li className="flex gap-4">
    <div className="h-6 w-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold shrink-0">
      {index + 1}
    </div>
    <div>
      <p className="font-bold">{title}</p>
      <p className="text-sm opacity-60">{desc}</p>
    </div>
  </li>
));

export default function LandingPage({ onAnalyze, isAnalyzing }: LandingPageProps) {
  const [file, setFile] = useState<File | null>(null);
  const [language, setLanguage] = useState('English');
  const [examState, setExamState] = useState('');
  const [dateRange, setDateRange] = useState('');

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.png', '.jpg', '.jpeg']
    },
    multiple: false
  } as any);

  const handleStart = async () => {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      onAnalyze(base64, file.type, { language, examState, dateRange });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-brand-ink selection:bg-brand-ink selection:text-brand-paper">
      <div className="max-w-5xl w-full space-y-16">
        <div className="space-y-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-mint text-[10px] font-bold uppercase tracking-[0.2em] text-brand-ink/60 border border-brand-ink/5"
          >
            <Sparkles className="w-3 h-3" /> Your Personal AI Tutor
          </motion.div>
          <h1 
            className="text-8xl md:text-9xl font-display font-black tracking-tighter leading-[0.85] text-balance text-brand-ink"
            style={{ fontFamily: 'monospace' }}
          >
            Study <span className="font-serif italic font-normal text-brand-electric">Partner</span>
          </h1>
          <p 
            className="text-xl md:text-2xl text-brand-ink/80 max-w-2xl mx-auto font-medium text-balance"
            style={{ fontFamily: 'monospace' }}
          >
            Upload your material and let's transform it into an <span className="font-serif italic">immersive</span> learning experience.
          </p>
        </div>

        <div className="grid md:grid-cols-12 gap-8 items-stretch" style={{ backgroundColor: '#1b0202', padding: '2rem', borderRadius: '3rem' }}>
          <div className="md:col-span-7 bento-card !p-0 overflow-hidden border-brand-ink/10 shadow-2xl">
            <div className="p-8 space-y-8" style={{ backgroundColor: '#331d1d' }}>
              <div 
                {...getRootProps()} 
                className={`group relative border-2 border-dashed rounded-3xl p-12 transition-all cursor-pointer flex flex-col items-center justify-center gap-4 ${
                  isDragActive ? 'border-brand-electric bg-brand-electric/5 scale-[0.99]' : 'border-brand-ink/10 hover:border-brand-ink/20 hover:bg-white/50'
                }`}
                style={{ backgroundColor: '#c6ccb4' }}
              >
                <input {...getInputProps()} />
                {file ? (
                  <div className="flex flex-col items-center gap-4">
                    <div className="p-4 bg-brand-mint rounded-2xl shadow-inner">
                      {file.type.includes('pdf') ? <FileText className="w-10 h-10" /> : <ImageIcon className="w-10 h-10" />}
                    </div>
                    <div className="text-center">
                      <p className="font-display font-bold text-lg">{file.name}</p>
                      <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); setFile(null); }} className="mt-2 text-[10px] uppercase tracking-widest font-bold opacity-40 hover:opacity-100">Change File</Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="p-5 bg-brand-ink rounded-3xl text-brand-paper shadow-2xl group-hover:scale-110 transition-transform duration-500">
                      <Upload className="w-8 h-8" />
                    </div>
                    <div className="text-center space-y-1">
                      <p className="font-display font-bold text-xl text-brand-ink">Drop your material here</p>
                      <p className="text-[10px] text-brand-ink/60 uppercase tracking-widest font-black">PDF or Image • Max 10MB</p>
                    </div>
                  </>
                )}
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest font-black ml-1" style={{ fontSize: '13px', color: '#edd7d7' }}>Language</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="bg-white/50 border-brand-ink/5 h-12 rounded-2xl font-bold focus:ring-brand-electric/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-2xl border-brand-ink/10">
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Hindi">Hindi</SelectItem>
                      <SelectItem value="Telugu">Telugu</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest font-black ml-1" style={{ fontSize: '13px', color: '#ffffff' }}>Exam State</Label>
                  <Input 
                    placeholder="e.g. Telangana" 
                    value={examState}
                    onChange={(e) => setExamState(e.target.value)}
                    className="bg-white/50 border-brand-ink/5 h-12 rounded-2xl font-bold focus:ring-brand-electric/20"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] uppercase tracking-widest font-black ml-1 px-2 py-1 rounded" style={{ backgroundColor: '#ffe0e0', fontFamily: 'Courier New', fontSize: '17px', color: '#0a0000' }}>Exam Date Range</Label>
                <Input 
                  placeholder="e.g. May 15 - June 10" 
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="bg-white/50 border-brand-ink/5 h-12 rounded-2xl font-bold focus:ring-brand-electric/20"
                  style={{ backgroundColor: '#e3cccc' }}
                />
              </div>

              <Button 
                className="w-full h-16 text-xl font-display font-black hover:bg-brand-ink/90 rounded-3xl shadow-2xl transition-all active:scale-[0.98] disabled:opacity-50"
                disabled={!file || isAnalyzing}
                onClick={handleStart}
                style={{ backgroundColor: '#efdc9d', color: '#fdf7f7' }}
              >
                {isAnalyzing ? (
                  <div className="flex items-center gap-3" style={{ color: '#070000' }}>
                    <Loader2 className="h-6 w-6 animate-spin" />
                    Analyzing...
                  </div>
                ) : (
                  <div className="flex items-center gap-3" style={{ color: '#070000' }}>
                    Start Learning <ArrowRight className="w-6 h-6" />
                  </div>
                )}
              </Button>
            </div>
          </div>

          <div className="md:col-span-5 flex flex-col gap-8">
            <div className="bento-card flex-1 border-brand-ink/5 bg-brand-ink text-brand-paper shadow-2xl relative overflow-hidden" style={{ backgroundColor: '#1d0202' }}>
              <div className="absolute top-0 right-0 p-8 opacity-20">
                <Globe className="w-32 h-32 rotate-12" />
              </div>
              <div className="relative z-10 space-y-8">
                <h3 className="text-3xl font-display font-black tracking-tight leading-none text-brand-paper">
                  The Full <br /> <span className="font-serif italic font-normal text-brand-mint">Experience</span>
                </h3>
                <ul className="space-y-6">
                  {[
                    { title: 'AI Podcast', desc: 'Engaging storytelling explanation.' },
                    { title: 'Visual Aids', desc: 'Mind maps & infographics.' },
                    { title: 'Smart Quizzes', desc: 'Test your knowledge.' },
                    { title: 'Study Strategy', desc: 'Personalized plan.' }
                  ].map((item, i) => (
                    <li key={i} className="flex gap-4 items-start">
                      <div className="h-6 w-6 rounded-full bg-brand-mint text-brand-ink flex items-center justify-center text-[10px] font-black shrink-0 mt-1">
                        0{i + 1}
                      </div>
                      <div>
                        <p className="font-display font-bold text-lg leading-tight text-brand-paper">{item.title}</p>
                        <p className="text-sm text-brand-paper/70 leading-tight" style={i === 0 ? { backgroundColor: '#120202' } : {}}>{item.desc}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="bento-card border-brand-ink/5 bg-brand-mint/30 flex items-center justify-center py-6">
              <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] opacity-60">
                <Sparkles className="w-4 h-4 text-brand-electric" /> Powered by Gemini 1.5 Flash
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
