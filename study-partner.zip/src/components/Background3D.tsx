import { motion } from "motion/react";

export default function Background3D() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-brand-paper">
      {/* Base 3D Study Image - Clearer and more vibrant */}
      <div className="absolute inset-0 opacity-40">
        <img 
          src="https://images.unsplash.com/photo-1523240715630-971c76f33400?auto=format&fit=crop&q=80&w=1920" 
          alt="Students Studying" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Soft Overlays for Readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-paper/40 via-transparent to-brand-paper/60 pointer-events-none" />
      <div className="absolute inset-0 backdrop-blur-[2px] pointer-events-none" />
      
      {/* Animated Light Orbs - More vibrant colors */}
      <motion.div
        animate={{
          x: [0, 100, 0],
          y: [0, 50, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-20 -left-20 h-[600px] w-[600px] rounded-full bg-brand-electric/10 blur-[120px] will-change-transform"
      />

      <motion.div
        animate={{
          x: [0, -80, 0],
          y: [0, 100, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2
        }}
        className="absolute -bottom-20 -right-20 h-[700px] w-[700px] rounded-full bg-brand-mint/20 blur-[150px] will-change-transform"
      />

      {/* Subtle Grid */}
      <div 
        className="absolute inset-0 opacity-[0.03]" 
        style={{ 
          backgroundImage: `linear-gradient(to right, #000 1px, transparent 1px), linear-gradient(to bottom, #000 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }} 
      />
    </div>
  );
}
